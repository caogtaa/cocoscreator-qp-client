module.exports = require("./dist/bytebuffer-node.js");
