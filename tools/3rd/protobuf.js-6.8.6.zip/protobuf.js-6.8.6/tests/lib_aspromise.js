if (typeof Promise !== "undefined")
    require("../lib/aspromise/tests");
