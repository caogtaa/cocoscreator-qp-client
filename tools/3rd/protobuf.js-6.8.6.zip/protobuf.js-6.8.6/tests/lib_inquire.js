var protobuf = require("..");

if (protobuf.util.isNode)
    require("../lib/inquire/tests");
