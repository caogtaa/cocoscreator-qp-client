require("../../lib/fetch/tests"); // requires fs
