require("../lib/eventemitter/tests");
