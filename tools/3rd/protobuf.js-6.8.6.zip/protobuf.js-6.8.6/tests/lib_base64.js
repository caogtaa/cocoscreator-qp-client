require("../lib/base64/tests");
