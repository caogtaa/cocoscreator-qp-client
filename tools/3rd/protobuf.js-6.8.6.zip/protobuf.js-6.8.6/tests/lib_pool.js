if (typeof Uint8Array !== "undefined")
    require("../lib/pool/tests");
